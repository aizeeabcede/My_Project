
<?php
$firstName = $_POST['fname'];
$middleName = $_POST['mname'];
$lastName = $_POST['lname'];
$gender = $_POST['Gender'];
// Birthday
$month = $_POST['month'];
$day= $_POST['day'];
$year= $_POST['Year'];
// Program and student type
$program = $_POST['course'];
$studentType= $_POST['status'];
$address = $_POST['add'];
?>
<html>
<body>
First Name: <strong><?php echo $firstName; ?></strong><br />
Middle Name: <strong><?php echo $middleName; ?></strong><br />
Last Name: <strong><?php echo $lastName; ?></strong><br />
Gender: <strong><?php echo $gender; ?></strong><br />
Birthday: <strong><?php echo $birthday; ?></strong><br />
Program: <strong><?php echo $program; ?></strong><br />
Student Type: <strong><?php echo $studentType; ?></strong><br />
Address: <pre><?php echo $address; ?></pre><br />
</body>
</html>
