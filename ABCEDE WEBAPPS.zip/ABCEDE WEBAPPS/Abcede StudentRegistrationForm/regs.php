<html>
<head>
<center> <h1> Student Registration Form </h1>
</head>
<body>
<form action = "register.php" method="POST">
<div>
<center>
<table border="1" cellpadding="10">
	<tr>
	<td>&nbsp; First Name&nbsp;<br><input type= "text" name="fname" size="20" placeholder= "First Name"></td>
	<td>&nbsp;Middle Name&nbsp;<br><input type= "text" name = "mname" size="20" placeholder= "Middle Name"></td>
	<td>&nbsp;Last Name&nbsp;<br><input type= "text" name = "lname" size="20" placeholder= "Last Name Name"></td>
	</tr>

	<tr>
	<td>Gender</td>
	<td>Male<input type="radio" name="Gender" value = "male"></td>
	<td>Female<input type="radio" name="Gender" value = "female"></td>
	</tr>

	<td colspan="3"> Birthday </td>
	<tr>
	<td> Month
	<select name = "month">
	<option value = "January">January</option>
	<option value = "Febuary">Febuary</option>
	<option value>March</option>
	<option value>April</option>
	<option value>May</option>
	<option value>June</option>
	<option value>July</option>
	<option value>August</option>
	<option value>September</option>
	<option value>October</option>
	<option value>November</option>
	<option value>December</option>
	</select>
	</td>

<td> Day
	<select name = "day">
	<option value> 1 </option>
	<option> 2 </option>
	<option> 3 </option>
	<option> 4 </option>
	<option> 5 </option>
	<option> 6 </option>
	<option> 7 </option>
	<option> 8 </option>
	<option> 9 </option>
	<option> 10 </option>
	<option> 11</option>
	<option> 12</option>
	<option> 13 </option>
	<option> 14</option>
	<option> 15 </option>
	<option> 16 </option>
	<option> 17 </option>
	<option> 18 </option>
	<option> 19 </option>
	<option> 21 </option>
	<option> 22 </option>
	<option> 23 </option>
	<option> 24 </option>
	<option> 25 </option>
	<option> 26 </option>
	<option> 27 </option>
	<option> 28 </option>
	<option> 29 </option>
	<option> 30 </option>
	<option> 31 </option>
	</td>

	<td> Year
	<select>
	<option> 1990 </option>
	<option> 1991 </option>
	<option> 1992 </option>
	<option> 1993 </option>
	<option> 1995 </option>
	<option> 1996 </option>
	<option> 1997 </option>
	<option> 1998 </option>
	<option> 1999 </option>
	<option> 2000 </option>
	<option> 2001</option>
	<option> 2002</option>
	<option> 2003 </option>
	<option> 2004</option>
	<option> 2006 </option>
	<option> 2006 </option>
	<option> 2007 </option>
	<option> 2008 </option>
	<option> 2009 </option>
	<option> 2010 </option>
	<option> 2011 </option>
	<option> 2012 </option>
	<option> 2013 </option>
	<option> 2014 </option>
	<option> 2015 </option>
	<option> 2016 </option>
	</td>

    <tr>
	<td> Program </td>
	<td colspan="2"> <select>
	<option> Bachelor Of Science In Information Systems </option>
	<option> Bachelor Of Science In Accountancy </option>
	<option> Bachelor Of Science In Accounting Technology </option>
	<option> Bachelor Of Science In Social Worksi  </option>
	<option> Bachelor Of Arts In Broadcasting </option>
	</select>
	</td>
	</tr>

	<tr>
	<td colspan="3"> Student Type </td>
	</tr>

	<tr>
	<td colspan="3">
	<ul>
	<br><input type="radio" value="full" name="Type">Full Scholar
	<br><input type="radio" value="partial" name="Type">Partial Scholar
	<br><input type="radio" value="payee" name="Type">Payee
	</ul>
	</td>
	</tr>

	<tr>
	<td colspan="3"> Address </td>
	</tr>

    <tr>
    <td colspan="3">
    <textarea width="100%" colspan="3">
    </textarea>
    </td>
    </tr>

    <tr> <td>
    <input type = "SUBMIT" value="Submit Registration">
    </td> </tr>






</center>
</div>
</form>
</body>
</html>
