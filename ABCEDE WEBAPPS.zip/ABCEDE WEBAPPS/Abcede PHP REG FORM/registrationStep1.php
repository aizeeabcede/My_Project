<html>
<head>
<center> <h1> Student Registration Form (Step 1 out of 6) </h1>
</head>
<body>
<form action = "registrationStep2.php" method="GET">
<div>
<center>
<link rel="stylesheet" type="text/css" href="style.css">
<table border="1" cellpadding="10">
	<tr>
	<td>&nbsp; First Name&nbsp;<br><input type= "text" value = "<?php echo $firstName; ?>"> </td>
	<td>&nbsp;Middle Name&nbsp;<br><input type= "text" value = "<?php echo $middleName; ?>"></td>
	<td>&nbsp;Last Name&nbsp;<br><input type= "text" value = "<?php echo $lastName; ?>"></td>
	</tr>

    <tr> <td> <center>
    <input type = "SUBMIT" value="PROCEED TO THE NEXT PAGE">
    </center> </td> </tr>

</center>
</div>
</form>
</body>
</html>
