<?php
$firstName = $_GET ['first_name'];
$middleName = $_GET ['middle_name'];
$flastName = $_GET ['last_name'];
$gender = $_GET ['gender'];
?>
<html>
<head>
<center> <h1> Student Registration Form (Step 3 out of 6) </h1>
</head>
<body>
<form action = "registrationStep4.php" method="GET">
<div>
<center>
<link rel="stylesheet" type="text/css" href="style.css">
<table border="1" cellpadding="10">

<tr>
	<td>First Name<br><input type= "text" value = "<?php echo $firstName; ?>"> </td>
	<td>Middle Name<br><input type= "text" value = "<?php echo $middleName; ?>"></td>
	<td>Last Name<br><input type= "text" value = "<?php echo $lastName; ?>"></td>
	</tr>

<tr>
	<td>Gender</td>
	<td>Male<input type="radio" value = "<?php echo $gender; ?>"  value = "male"></td>
	<td>Female<input type="radio" "<?php echo $gender; ?>"  value = "female"></td>
</tr>

<td colspan="3"> Birthday </td>
	<tr>
	<td> Month
	<select name = "month">
	<option value = "January">January</option>
	<option value = "Febuary">Febuary</option>
	<option value>March</option>
	<option value>April</option>
	<option value>May</option>
	<option value>June</option>
	<option value>July</option>
	<option value>August</option>
	<option value>September</option>
	<option value>October</option>
	<option value>November</option>
	<option value>December</option>
	</select>
	</td>

	<td> Day
	<select name = "day">
	<option value> 1 </option>
	<option value> 2 </option>
	<option value> 3 </option>
	<option value> 4 </option>
	<option value> 5 </option>
	<option value> 6 </option>
	<option value> 7 </option>
	<option value> 8 </option>
	<option value> 9 </option>
	<option value> 10 </option>
	<option value> 11</option>
	<option value> 12</option>
	<option value> 13 </option>
	<option value> 14</option>
	<option value> 15 </option>
	<option value> 16 </option>
	<option value> 17 </option>
	<option value> 18 </option>
	<option value> 19 </option>
	<option value> 21 </option>
	<option value> 22 </option>
	<option value> 23 </option>
	<option value> 24 </option>
	<option value> 25 </option>
	<option value> 26 </option>
	<option value> 27 </option>
	<option value> 28 </option>
	<option value> 29 </option>
	<option value> 30 </option>
	<option value> 31 </option>
	</td>

	<td> Year
	<select>
	<option value> 1990 </option>
	<option value> 1991 </option>
	<option value> 1992 </option>
	<option value> 1993 </option>
	<option value> 1995 </option>
	<option value> 1996 </option>
	<option value> 1997 </option>
	<option value> 1998 </option>
	<option value> 1999 </option>
	<option value> 2000 </option>
	<option value> 2001</option>
	<option value> 2002</option>
	<option value> 2003 </option>
	<option value> 2004</option>
	<option value> 2006 </option>
	<option value> 2006 </option>
	<option value> 2007 </option>
	<option value> 2008 </option>
	<option value> 2009 </option>
	<option value> 2010 </option>
	<option value> 2011 </option>
	<option value> 2012 </option>
	<option value> 2013 </option>
	<option value> 2014 </option>
	<option value> 2015 </option>
	<option value> 2016 </option>
	</td>



	 <tr> <td colspan ="3">
    <input type = "SUBMIT" value="PROCEED TO THE NEXT PAGE">
    <a href = "registrationStep2.php"> back to Step 2 </a>
    </td> </tr>

</center>
</div>
</form>
</body>
</html>
