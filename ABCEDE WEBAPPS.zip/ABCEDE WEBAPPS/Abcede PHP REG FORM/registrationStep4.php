<?php
$firstName = $_GET ['first_name'];
$middleName = $_GET ['middle_name'];
$flastName = $_GET ['last_name'];
$gender = $_GET ['gender'];
$month = $_GET ['month'];
$day = $_GET ['day'];
$year = $_GET ['year'];
?>
<html>
<head>
<center> <h1> Student Registration Form (Step 4 out of 6) </h1>
</head>
<body>
<form action = "registrationStep5.php" method="GET">
<div>
<center>
<link rel="stylesheet" type="text/css" href="style.css">
<table border="1" cellpadding="10">

<tr>
	<td> Program </td>
	<td colspan="2"> <select>
	<option value> Bachelor Of Science In Information Systems </option>
	<option value> Bachelor Of Science In Accountancy </option>
	<option value> Bachelor Of Science In Accounting Technology </option>
	<option value> Bachelor Of Science In Social Worksi  </option>
	<option value> Bachelor Of Arts In Broadcasting </option>
	</select>
	</td>
	</tr>

	<tr> <td colspan ="3">
    <input type = "SUBMIT" value="PROCEED TO THE NEXT PAGE">
    <a href = "registrationStep3.php"> back to Step 3 </a>
    </td> </tr>

</center>
</div>
</form>
</body>
</html>

