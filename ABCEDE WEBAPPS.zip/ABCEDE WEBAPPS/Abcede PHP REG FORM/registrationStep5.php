<?php
$firstName = $_GET ['first_name'];
$middleName = $_GET ['middle_name'];
$flastName = $_GET ['last_name'];
$gender = $_GET ['gender'];
$month = $_GET ['month'];
$day = $_GET ['day'];
$year = $_GET ['year'];
$program = $_GET ['program'];
?>
<html>
<head>
<center> <h1> Student Registration Form (Step 5 out of 6) </h1>
</head>
<body>
<form action = "registrationStep6.php" method="GET">
<div>
<center>
<link rel="stylesheet" type="text/css" href="style.css">
<table border="1" cellpadding="10">

<tr>
	<td colspan="3"> Student Type </td>
	</tr>

	<tr>
	<td colspan="3">
	<ul>
	<br><input type="radio" value="full" name="Type">Full Scholar
	<br><input type="radio" value="partial" name="Type">Partial Scholar
	<br><input type="radio" value="payee" name="Type">Payee
	</ul>
	</td>
	</tr>

<tr> <td colspan ="3">
    <input type = "SUBMIT" value="PROCEED TO THE NEXT PAGE">
    <a href = "registrationStep4.php"> back to Step 4 </a>
    </td> </tr>

</center>
</div>
</form>
</body>
</html>


