<html>
<head>
<center> <h1> Student Registration Form (Step 6 out of 6) </h1>
</head>
<body>
<form action = "registrationStep1.php" method="GET">
<div>
<center>
<link rel="stylesheet" type="text/css" href="style.css">
<table border="1" cellpadding="10">

<tr>
	<td colspan="3"> Address </td>
	</tr>

	<tr>
    <td colspan="3">
    <textarea width="100%" colspan="3">
    </textarea>
    </td>
    </tr>

<tr> <td colspan ="3">
    <input type = "SUBMIT" value="BACK TO FIRSTPAGE">
    <a href = "registrationStep5.php"> back to Step 5 </a>
    </td> </tr>

</center>
</div>
</form>
</body>
</html>


