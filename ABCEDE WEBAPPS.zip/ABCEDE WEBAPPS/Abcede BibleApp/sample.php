<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="vendor/bootstrapv3/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="vendor/bootstrapv3/css/bootstrap-theme.css">
</head>
<body>
	<div class="container" id="main">
		<div class="row">
			<div class="col-md-12"> 
				<div id="iframe-container" class="embed-responsive embed-responsive-4by3">
				  <iframe class="embed-responsive-item" src="index.php"></iframe>
				</div>
			</div>
		</div>
	</div>

	<script type="text/javascript" src="vendor/bootstrapv3/js/jquery-1.11.3.min.js"></script>
	<script type="text/javascript" src="vendor/bootstrapv3/js/bootstrap.js"></script>
</body>
</html>